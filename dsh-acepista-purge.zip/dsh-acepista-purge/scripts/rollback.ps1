# dsh-acepista-purge 回滚脚本
# 从 backup 还原 profile patch，移除插件行

$ErrorActionPreference = "Stop"

$PluginDir = "F:\A-001\dsh-acepista-purge"
$Backup = "$PluginDir\backup\profile-cordis.patch.yml.bak"
$ProfilePatch = "$env:USERPROFILE\.dsh\profiles\desktop\cordis.patch.yml"

if (Test-Path $Backup) {
    Copy-Item $Backup $ProfilePatch -Force
    Write-Host "[acepista] 已从备份还原 profile patch"
} else {
    Write-Warning "[acepista] 备份不存在，手动移除插件行"
    if (Test-Path $ProfilePatch) {
        $Content = Get-Content $ProfilePatch -Raw
        $Content = $Content -replace '(?s)- insert:\r?\n\s+- id: dsh-acepista-purge.*?config:\r?\n\s+enabled: true', ''
        Set-Content $ProfilePatch $Content
        Write-Host "[acepista] 已手动移除插件行"
    }
}

Write-Host "[acepista] 回滚完成。请重启 Harness。"
