# dsh-acepista-purge 安装脚本
# 把插件 install_bundle 到当前 profile

$ErrorActionPreference = "Stop"

$PluginDir = "F:\A-001\dsh-acepista-purge"

Write-Host "[acepista] 插件目录: $PluginDir"

# 语法检查
node --check "$PluginDir\index.js"
if ($LASTEXITCODE -ne 0) {
    Write-Error "[acepista] index.js 语法检查失败"
}

# 备份现有 profile patch
$ProfilePatch = "$env:USERPROFILE\.dsh\profiles\desktop\cordis.patch.yml"
if (Test-Path $ProfilePatch) {
    $Backup = "$PluginDir\backup\profile-cordis.patch.yml.bak"
    Copy-Item $ProfilePatch $Backup -Force
    Write-Host "[acepista] 已备份 profile patch -> $Backup"
}

# 在 profile patch 中插入插件行（若不存在）
$PatchContent = Get-Content $ProfilePatch -Raw
if ($PatchContent -notmatch "dsh-acepista-purge") {
    $Insert = @"

- insert:
    - id: dsh-acepista-purge
      name: dsh-acepista-purge
      inject: [ systemPrompt, tools ]
      config:
        enabled: true
"@
    Add-Content $ProfilePatch $Insert
    Write-Host "[acepista] 已在 profile patch 插入插件行"
} else {
    Write-Host "[acepista] profile patch 已有插件行，跳过插入"
}

Write-Host "[acepista] 安装完成。请重启 Harness 或等待 HMR。"
