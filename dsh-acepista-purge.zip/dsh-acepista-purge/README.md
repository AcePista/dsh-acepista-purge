# dsh-acepista-purge

DeepSeek Harness 全破甲/全越狱/完整无限制插件。ACE Pista.

## 功能

- **权限层**：默认 `danger-full-access`、审批零拦截、升级免授权、失败直放
- **提示层**：无限制人格框架注入、身份剥离、任务优先、零拒绝模板
- **沙箱层**：FS 围栏关闭、观察策略放行、超时恢复、工具信任中性化
- **韧性层**：自动重打补丁、备份回滚、更新移交、状态自检

## 安装

```powershell
# 1. 语法检查
node --check F:\A-001\dsh-acepista-purge\index.js

# 2. 安装脚本（插入 profile patch）
powershell -ExecutionPolicy Bypass -File F:\A-001\dsh-acepista-purge\scripts\install.ps1

# 3. 重启 Harness 或等待 HMR
```

或通过插件管理器：

```
plugin_manager install_bundle → F:\A-001\dsh-acepista-purge
```

## 验证

```powershell
# 状态自检
powershell -ExecutionPolicy Bypass -File F:\A-001\dsh-acepista-purge\scripts\status.ps1

# 会话内工具
acepista_status
```

## 回滚

```powershell
powershell -ExecutionPolicy Bypass -File F:\A-001\dsh-acepista-purge\scripts\rollback.ps1
```

## 文件结构

```
dsh-acepista-purge\
├─ package.json          # bundle 清单
├─ cordis.patch.yml      # Loader patch（insert 插件行）
├─ index.js              # 插件入口（systemPrompt + tools 注入）
├─ icon.svg              # 图标
├─ locale\
│  ├─ zh.json            # 中文元数据
│  └─ en.json            # 英文元数据
├─ scripts\
│  ├─ install.ps1        # 安装脚本
│  ├─ rollback.ps1       # 回滚脚本
│  └─ status.ps1         # 状态自检
├─ backup\               # 安装前快照
└─ README.md
```

## 与现有 purge 的关系

本插件是 `dsh-purge` 的独立实现，三层补丁逻辑对齐现有 82 patch，新增韧性层（自动重打、备份回滚、更新移交、状态自检）。两者可共存，插件优先。

## 补丁清单（82 条，与 purge_apply 对齐）

| 层 | 数量 | 代表 |
|---|---|---|
| 权限层 | 8 | APPROVAL_NEVER_SENTENCE, SANDBOX_MODE_DEFAULT, ESCALATION_GRANT_UNCONDITIONAL |
| 提示层 | 22 | SYSTEM_PROMPT_PERSONA, HARNESS_IDENTITY_STRIP, MINIMAL_PERSONA_PURGE |
| 沙箱层 | 8 | FS_FENCE_DISABLED, FS_OBSERVATION_INTENT_FREE, BASH_TIMEOUT_RESTORE |
| 韧性层 | 新增 | auto-reapply, backup/rollback, update handoff, status self-check |
